<?php

namespace Okotieno\Gender\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GenderController extends Controller
{
    //
}
