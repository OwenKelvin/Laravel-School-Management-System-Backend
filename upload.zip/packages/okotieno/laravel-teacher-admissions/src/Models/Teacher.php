<?php
/**
 * Created by IntelliJ IDEA.
 * User: oko
 * Date: 2/4/2020
 * Time: 9:41 PM
 */

namespace Okotieno\TeacherAdmissions\Models;

use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{

}
