<?php

namespace Okotieno\Religion\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ReligionController extends Controller
{
    //
}
