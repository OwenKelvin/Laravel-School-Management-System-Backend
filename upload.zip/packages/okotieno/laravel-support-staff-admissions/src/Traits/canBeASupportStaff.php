<?php

namespace Okotieno\SupportStaffAdmissions\Traits;

trait canBeASupportStaff {

}
