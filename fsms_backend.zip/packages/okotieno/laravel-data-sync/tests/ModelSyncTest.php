<?php
/**
 * Created by IntelliJ IDEA.
 * User: oko
 * Date: 6/30/2019
 * Time: 9:33 AM
 */

namespace Okotieno\LaravelDataSync\Test;

use Tests\TestCase;

class ModelSyncTest extends TestCase
{
    /** @test */
    public function sync_table_exists()
    {

    }
}
