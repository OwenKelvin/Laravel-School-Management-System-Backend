publishing the views
run php artisan vendor:publish --provider=Okotieno\LaravelLMS\LaravelLMSServiceProvider
