<?php

namespace Okotieno\LMS\Models;

use Illuminate\Database\Eloquent\Model;

class LibraryBookPublisher extends Model
{
    protected $fillable = ['name'];
}
