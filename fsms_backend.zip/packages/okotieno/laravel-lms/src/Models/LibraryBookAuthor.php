<?php

namespace Okotieno\LMS\Models;

use Illuminate\Database\Eloquent\Model;

class LibraryBookAuthor extends Model
{
    protected $fillable = ['name'];
}
