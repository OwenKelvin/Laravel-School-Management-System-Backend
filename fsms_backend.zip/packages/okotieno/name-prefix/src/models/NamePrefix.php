<?php

namespace Okotieno\NamePrefix\Models;

use Illuminate\Database\Eloquent\Model;

class NamePrefix extends Model
{
    public $timestamps = false;
}
