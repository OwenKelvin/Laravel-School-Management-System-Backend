<?php

namespace Okotieno\NamePrefix\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class NamePrefixController extends Controller
{
    //
}
