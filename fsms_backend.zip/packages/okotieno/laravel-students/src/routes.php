<?php

Route::middleware(['auth:api', 'bindings'])->group(function () {

});

