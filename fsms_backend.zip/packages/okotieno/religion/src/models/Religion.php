<?php

namespace Okotieno\Religion\Models;

use Illuminate\Database\Eloquent\Model;

class Religion extends Model
{
    public $timestamps = false;
}
