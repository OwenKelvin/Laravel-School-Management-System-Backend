<?php

namespace Okotieno\StudentAdmissions\Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function testBasicTest()
    {
        echo "oooooooooooo";
        $this->assertTrue(false);
    }
}
